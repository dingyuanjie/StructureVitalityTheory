"""CoreCPU-Lab research package."""
