/* Offline build: React UMD is vendored; TypeScript is used only as a JSX compiler. */
const fs=require('fs'),path=require('path');
let ts;try{ts=require('typescript')}catch(e){throw new Error('请先安装 typescript: npm install');}
const root=__dirname,read=p=>fs.readFileSync(path.join(root,p),'utf8');
const compiled=ts.transpileModule(read('src/app.jsx'),{compilerOptions:{target:ts.ScriptTarget.ES2018,jsx:ts.JsxEmit.React,allowJs:true},reportDiagnostics:true,fileName:'app.jsx'});
const errors=(compiled.diagnostics||[]).filter(d=>d.category===ts.DiagnosticCategory.Error);if(errors.length)throw new Error(errors.map(e=>ts.flattenDiagnosticMessageText(e.messageText,'\n')).join('\n'));
const code=['vendor/react.production.min.js','vendor/react-dom.production.min.js','src/engine.js','src/renderer.js'].map(read).concat(compiled.outputText).map(s=>s.replace(/<\/script/gi,'<\\/script')).join('\n;\n');
const html=`<!doctype html>\n<!-- React / ReactDOM license:\n${read('vendor/LICENSE-react.txt')}\n-->\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#080d17"><title>313 · 多尺度宇宙架构实验室</title><style>${read('src/styles.css')}</style></head><body><div id="root"></div><noscript>请启用 JavaScript 以运行宇宙模拟器。</noscript><script>${code}</script></body></html>\n`;
fs.writeFileSync(path.join(root,'index.html'),html);console.log('Built index.html:',Buffer.byteLength(html),'bytes');
