/* Canvas renderer: state is derived from seed + tick, never from frame order. */
(function(global){
 'use strict';
 const {TAU,hash,rng,clamp}=global.UniCore;
 const palette=['#92a9ff','#e5a5d7','#76d8e2','#f7ca85','#a4c6fa','#ab8ff1'];
 const labelColors=['#dfeaff','#b6c9e8','#c0d9ee'];
 function pos(n,scene,t){
  const id=scene.level.id,phase=scene.effect.samplePhase, a=n.a;
  if(n.external){const x=.82*Math.cos(a+phase*.002),y=.82*Math.sin(a+phase*.002);return {x,y,r:5+(n.strength||0)*1.7};}
  if(id==='universe'){const group=n.index%7;const centers=[[-.61,-.38],[.05,-.53],[.58,-.28],[-.43,.43],[.26,.34],[.68,.55],[-.04,-.03]];const c=centers[group];const expand=1+phase*.000006;return {x:(c[0]+Math.cos(a)*n.u*.28)*expand,y:(c[1]+Math.sin(a)*n.u*.22)*expand,r:2+n.v*5.1};}
  if(id==='galaxy'){const rr=.035+.92*Math.sqrt(n.u),ang=n.index%4*TAU/4+rr*3.8+(n.v-.5)*.64+phase*.0008/Math.pow(rr+.24,.65);return{x:Math.cos(ang)*rr,y:Math.sin(ang)*rr*.67,r:.55+n.w*1.9};}
  if(id==='system'){const rr=.14+(n.index+1)*.083,ang=a+phase*.019/Math.pow(rr/.24,1.5);return{x:Math.cos(ang)*rr,y:Math.sin(ang)*rr*.70,r:4+n.u*6};}
  if(id==='planet'){const lon=a+phase*.002,lat=(n.v-.5)*Math.PI;return{x:.77*Math.cos(lat)*Math.sin(lon),y:.75*Math.sin(lat),r:3+n.u*3,hidden:Math.cos(lon)<0};}
  if(id==='ecosystem'){const group=n.index%5,ang=group*TAU/5+a*.26;const rr=.12+.67*n.u;return{x:Math.cos(ang)*rr+(n.v-.5)*.16,y:Math.sin(ang)*rr*.78+(n.w-.5)*.13,r:3+n.z*5+Math.sin(phase*.035+a)};}
  if(id==='organism'){const row=Math.floor(n.index/11),col=n.index%11;return{x:(col-5)*.13+(n.v-.5)*.05,y:(row-2.5)*.19+(n.w-.5)*.055,r:8+n.u*8+Math.sin(phase*.04+a)*1.4};}
  if(id==='cell'){const rr=.18+.56*n.u,ang=a+Math.sin(phase*.01+a)*.13;return{x:Math.cos(ang)*rr,y:Math.sin(ang)*rr*.84,r:2.8+n.v*4};}
  if(id==='molecule'){const i=n.index;const ang=(i-1)*TAU/6+phase*.002;const rr=.58+Math.sin(phase*.037+i)*.035;return{x:i===0?0:Math.cos(ang)*rr,y:i===0?0:Math.sin(ang)*rr*.77,r:i===0?24:15+n.u*8};}
  if(id==='atom'){if(n.index<7){const rr=n.index===0?0:.055+n.u*.07;return{x:Math.cos(a)*rr,y:Math.sin(a)*rr,r:7+n.v*3};}const rr=.24+.52*n.u;return{x:Math.cos(a)*rr,y:Math.sin(a)*rr*.83,r:2+n.v*3};}
  const col=n.index%10,row=Math.floor(n.index/10);const x=(col-4.5)*.15,y=(row-3.5)*.18;return{x,y:y+Math.sin(x*9+phase*.028+row*.6)*.11,r:3+n.v*3};
 }
 function circle(ctx,x,y,r,fill,stroke,line=1){ctx.beginPath();ctx.arc(x,y,Math.max(.1,r),0,TAU);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=line;ctx.stroke();}}
 function ellipse(ctx,x,y,rx,ry,fill,stroke,line=1){ctx.beginPath();ctx.ellipse(x,y,Math.max(.1,rx),Math.max(.1,ry),0,0,TAU);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=line;ctx.stroke();}}
 function line(ctx,x,y,x2,y2,color,width=1){ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();}
 function glow(ctx,x,y,r,color){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'transparent');circle(ctx,x,y,r,g);}
 function drawBackground(ctx,w,h,seed,kind){const g=ctx.createRadialGradient(w*.50,h*.48,10,w*.50,h*.48,Math.max(w,h)*.65);g.addColorStop(0,'#101b37');g.addColorStop(.48,'#0a1124');g.addColorStop(1,'#060a13');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);const r=rng(hash(`${seed}/background/${kind}`));for(let i=0;i<170;i++){const x=r()*w,y=r()*h,alpha=r()*.35+.06,rad=r()*.65+.2;circle(ctx,x,y,rad,`rgba(165,192,245,${alpha})`);}ctx.strokeStyle='rgba(119,152,199,.055)';ctx.lineWidth=1;for(let x=0;x<w;x+=48)line(ctx,x,0,x,h,ctx.strokeStyle);for(let y=0;y<h;y+=48)line(ctx,0,y,w,y,ctx.strokeStyle);}
 const backgroundCache=new WeakMap();
 function render(canvas,scene,seed,tick,view,selected){
  const ctx=canvas.getContext('2d'),dpr=Math.min(2,global.devicePixelRatio||1),w=canvas.clientWidth,h=canvas.clientHeight;
  if(!w||!h)return [];
  if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
  ctx.setTransform(dpr,0,0,dpr,0,0);const bgKey=`${w}:${h}:${dpr}:${seed}:${scene.level.id}`;let bg=backgroundCache.get(canvas);if(!bg||bg.key!==bgKey){const c=document.createElement('canvas');c.width=canvas.width;c.height=canvas.height;const bc=c.getContext('2d');bc.scale(dpr,dpr);drawBackground(bc,w,h,seed,scene.level.id);bg={key:bgKey,canvas:c};backgroundCache.set(canvas,bg);}ctx.drawImage(bg.canvas,0,0,w,h);
  const cx=w/2+view.x,cy=h/2+view.y,base=Math.min(w,h)*.465*view.zoom, id=scene.level.id;
  const p=scene.nodes.map(n=>{const q=pos(n,scene,tick);return {...q,x:cx+q.x*base,y:cy+q.y*base,node:n};}).filter(q=>!q.hidden);
  const R=base;const hz=scene.effect.samplePhase;
  ctx.save();ctx.beginPath();ctx.rect(0,0,w,h);ctx.clip();
  if(id==='universe'){
   // Nearby cluster links: deterministic bounded O(n^2), tiny active scene only.
   for(let i=0;i<p.length;i++){if(p[i].node.external)continue;let best=null,dist=.095*R;for(let j=i+1;j<p.length;j++){const d=Math.hypot(p[i].x-p[j].x,p[i].y-p[j].y);if(d<dist){best=p[j];dist=d;}}if(best)line(ctx,p[i].x,p[i].y,best.x,best.y,'rgba(117,155,246,.23)');}
   glow(ctx,cx,cy,R*.83,'rgba(74,97,194,.13)');
  }
  if(id==='galaxy'){
   glow(ctx,cx,cy,R*.8,'rgba(92,105,238,.16)');glow(ctx,cx,cy,R*.22,'rgba(255,205,157,.66)');glow(ctx,cx,cy,R*.07,'rgba(255,237,211,.95)');
   for(let a=0;a<4;a++){ctx.beginPath();for(let i=0;i<=70;i++){const r=i/70*.97,ang=a*TAU/4+r*3.8+hz*.0008/Math.pow(r+.24,.65);const x=cx+Math.cos(ang)*r*R,y=cy+Math.sin(ang)*r*R*.67;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.strokeStyle='rgba(108,139,251,.095)';ctx.lineWidth=R*.055;ctx.stroke();}
  }
  if(id==='system'){
   for(let i=0;i<8;i++){const r=(.14+(i+1)*.083)*R;ellipse(ctx,cx,cy,r,r*.70,null,'rgba(136,164,211,.22)');}
   glow(ctx,cx,cy,R*.35,'rgba(255,166,55,.35)');glow(ctx,cx,cy,R*.17,'rgba(255,205,109,.78)');circle(ctx,cx,cy,R*.08,'#fff0b6');
  }
  if(id==='planet'){
   glow(ctx,cx,cy,R*.92,'rgba(76,181,235,.27)');const g=ctx.createRadialGradient(cx-R*.28,cy-R*.31,5,cx,cy,R*.82);g.addColorStop(0,'#3a8caf');g.addColorStop(.48,'#1d5c8d');g.addColorStop(1,'#081d3e');circle(ctx,cx,cy,R*.78,g,'rgba(119,211,245,.65)',2);
   ctx.save();ctx.beginPath();ctx.arc(cx,cy,R*.77,0,TAU);ctx.clip();const r=rng(hash(seed+scene.path));for(let i=0;i<19;i++){const a=r()*TAU+hz*.002,lat=(r()-.5)*2,x=cx+Math.sin(a)*Math.cos(lat)*R*.75,y=cy+Math.sin(lat)*R*.75;const rotation=r()*TAU,rx=R*(.06+r()*.24),ry=R*(.035+r()*.11);if(Math.cos(a)<0)continue;ctx.save();ctx.translate(x,y);ctx.rotate(rotation);ellipse(ctx,0,0,rx,ry,'rgba(75,155,117,.62)');ctx.restore();}for(let i=-2;i<=2;i++)ellipse(ctx,cx,cy+i*R*.21,R*.76*Math.sqrt(1-(i*.25)**2),R*.10,null,'rgba(170,229,239,.12)');ctx.restore();
  }
  if(id==='ecosystem'){
   for(let i=0;i<5;i++){const a=i*TAU/5;glow(ctx,cx+Math.cos(a)*R*.4,cy+Math.sin(a)*R*.32,R*.38,'rgba(63,156,100,.14)');}
   for(let i=1;i<p.length;i++){const j=(i*7+3)%i;line(ctx,p[i].x,p[i].y,p[j].x,p[j].y,'rgba(108,204,152,.14)');}
   circle(ctx,cx,cy,12,'#e8cb83');glow(ctx,cx,cy,55,'rgba(245,195,93,.17)');
  }
  if(id==='organism'){ellipse(ctx,cx,cy,R*.85,R*.72,'rgba(188,91,150,.065)','rgba(227,131,203,.28)',2);for(let i=0;i<p.length-1;i++){if(i%11!==10)line(ctx,p[i].x,p[i].y,p[i+1].x,p[i+1].y,'rgba(222,154,202,.17)',2);}}
  if(id==='cell'){
   ellipse(ctx,cx,cy,R*.83,R*.72,'rgba(91,190,166,.07)','rgba(104,220,186,.58)',3);ellipse(ctx,cx,cy,R*.79,R*.68,null,'rgba(104,220,186,.18)',1);ellipse(ctx,cx-R*.10,cy+R*.02,R*.23,R*.21,'rgba(127,126,226,.25)','rgba(168,160,242,.7)',2);circle(ctx,cx-R*.14,cy+R*.01,R*.067,'rgba(198,157,236,.7)');for(let i=0;i<4;i++){let a=i*TAU/4+.35;ctx.save();ctx.translate(cx+Math.cos(a)*R*.51,cy+Math.sin(a)*R*.43);ctx.rotate(a+.8);ellipse(ctx,0,0,R*.15,R*.058,'rgba(245,163,112,.28)','rgba(255,186,134,.55)');for(let j=-2;j<=2;j++)line(ctx,j*R*.040,-R*.033,j*R*.034,R*.033,'rgba(247,180,132,.38)');ctx.restore();}
  }
  if(id==='molecule'){for(let i=1;i<p.length;i++){if(p[i].node.external)continue;line(ctx,p[0].x,p[0].y,p[i].x,p[i].y,'rgba(161,205,246,.62)',5);if(i>1)line(ctx,p[i-1].x,p[i-1].y,p[i].x,p[i].y,'rgba(112,168,218,.27)',2);}}
  if(id==='atom'){
   const rr=rng(hash(`${seed}/${scene.path}/cloud`));for(let i=0;i<460;i++){const a=rr()*TAU,r=Math.sqrt(rr())*R*.83,b=.55+rr()*.45,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r*b*.80;circle(ctx,x,y,.6+rr()*1.2,`rgba(158,151,251,${.025+rr()*.12})`);}glow(ctx,cx,cy,R*.25,'rgba(166,121,245,.22)');
  }
  if(id==='particle'){for(let row=0;row<8;row++){ctx.beginPath();for(let i=0;i<=100;i++){const x=(i/100-.5)*1.5,y=(row-3.5)*.18+Math.sin(x*9+hz*.028+row*.6)*.11;i?ctx.lineTo(cx+x*R,cy+y*R):ctx.moveTo(cx+x*R,cy+y*R);}ctx.strokeStyle=`rgba(216,124,198,${.15+row*.022})`;ctx.lineWidth=1.6;ctx.stroke();}}
  const pulse=scene.effect.pulse;if(pulse>.01){const v=clamp(pulse/5,0,1);glow(ctx,cx,cy,R*.94,`rgba(255,179,102,${v*.26})`);for(let i=0;i<3;i++)circle(ctx,cx,cy,R*(.3+i*.28),null,`rgba(255,202,124,${v*.4})`,1.4);}
  for(const q of p){const n=q.node;let color=n.external?'#ffc982':palette[n.index%palette.length];const rr=q.r*Math.min(1.7,Math.sqrt(view.zoom));if(id==='galaxy'){circle(ctx,q.x,q.y,rr,color);if(n.index%23===0)glow(ctx,q.x,q.y,rr*4,'rgba(135,167,255,.27)');}else if(id==='universe'){glow(ctx,q.x,q.y,rr*3.8,'rgba(108,141,246,.32)');ellipse(ctx,q.x,q.y,rr*1.5,rr*.7,color);circle(ctx,q.x,q.y,rr*.4,'#e5eaff');}else if(id==='organism'){circle(ctx,q.x,q.y,rr,'rgba(204,118,181,.22)','rgba(232,164,212,.59)');circle(ctx,q.x+rr*.13,q.y-rr*.08,rr*.32,color);}else if(id==='molecule'||id==='system'){const g=ctx.createRadialGradient(q.x-rr*.35,q.y-rr*.35,0,q.x,q.y,rr);g.addColorStop(0,'#f1f4ff');g.addColorStop(.35,color);g.addColorStop(1,'#28324e');circle(ctx,q.x,q.y,rr,g);if(id==='system'&&n.index===5)ellipse(ctx,q.x,q.y,rr*1.7,rr*.68,null,'rgba(239,211,170,.7)');}else {circle(ctx,q.x,q.y,rr,`${color}b0`,`${color}d0`);}
    if(n.external){circle(ctx,q.x,q.y,rr+7,null,'#ffca83',1.5);line(ctx,q.x-13,q.y,q.x+13,q.y,'#ffc982');line(ctx,q.x,q.y-13,q.x,q.y+13,'#ffc982');}
    if(n.id===selected){circle(ctx,q.x,q.y,Math.max(8,rr+6),null,'#8fe8ea',1.4);ctx.font='11px system-ui';ctx.fillStyle='#baf7f5';ctx.textAlign='left';ctx.fillText(n.name,q.x+Math.max(10,rr+8),q.y-9);}
  }
  ctx.restore();
  // Orientation and scale indicators are viewport overlays, not universe state.
  ctx.font='10px system-ui';ctx.fillStyle='#8193ae';ctx.textAlign='left';ctx.fillText('MODEL SPACE  /  '+scene.level.en,15,h-31);line(ctx,15,h-18,75,h-18,'#7488a7');line(ctx,15,h-22,15,h-14,'#7488a7');line(ctx,75,h-22,75,h-14,'#7488a7');ctx.fillText(`${view.zoom.toFixed(2)}×`,85,h-15);
  return p;
 }
 global.UniRender={render,pos};
})(window);
