/* Universe laboratory — deterministic procedural multi-scale engine. */
(function (global) {
  'use strict';
  const TAU = Math.PI * 2, MAX_TICK = 12000;
  const LEVELS = [
    {id:'universe',cn:'宇宙',en:'UNIVERSE',unit:'可观测区域',scale:'~10²⁶ m',count:84,next:'galaxy',name:'宇宙网',desc:'以程序化星系分布表示大尺度结构。',rules:['结构生成','局部相互作用','层级聚合'],time:'宇宙学时间 · 示意',color:'#819eff'},
    {id:'galaxy',cn:'星系',en:'GALAXY',unit:'恒星 / 恒星系',scale:'~10²¹ m',count:560,next:'system',name:'旋涡星系',desc:'共享旋臂与轨道机制，参数决定每颗示意恒星的位置。',rules:['引力近似','旋臂分布','轨道运动'],time:'星系动力学 · 示意',color:'#9d9aff'},
    {id:'system',cn:'恒星系',en:'STAR SYSTEM',unit:'行星',scale:'~10¹³ m',count:8,next:'planet',name:'恒星与轨道',desc:'共享开普勒轨道近似；轨道半径决定周期。',rules:['中心引力','轨道周期','能量辐射'],time:'轨道时间 · 示意',color:'#f6be70'},
    {id:'planet',cn:'行星',en:'PLANET',unit:'地表区域',scale:'~10⁷ m',count:56,next:'ecosystem',name:'行星表面',desc:'种子生成地表区域；用简化经纬分布表现温度与地形。',rules:['空间分区','温度梯度','自转'],time:'行星时间 · 示意',color:'#5cd9d1'},
    {id:'ecosystem',cn:'生态',en:'ECOSYSTEM',unit:'生物实例',scale:'~10³ m',count:44,next:'organism',name:'生态网络',desc:'简化资源流与生物群落，以周期函数展示局部变化。',rules:['资源流动','反馈','群落组合'],time:'生态时间 · 示意',color:'#71d69c'},
    {id:'organism',cn:'生命',en:'ORGANISM',unit:'细胞样本',scale:'~1 m',count:66,next:'cell',name:'组织与细胞',desc:'细胞作为可复用组件，通过局部组织形成生命结构。',rules:['组件组合','物质交换','局部更新'],time:'生理时间 · 示意',color:'#e1a0d7'},
    {id:'cell',cn:'细胞',en:'CELL',unit:'分子集合',scale:'~10⁻⁵ m',count:32,next:'molecule',name:'细胞内部',desc:'膜、细胞核、线粒体与分子样本的示意布局。',rules:['边界约束','物质交换','局部运动'],time:'细胞时间 · 示意',color:'#83d4ac'},
    {id:'molecule',cn:'分子',en:'MOLECULE',unit:'原子',scale:'~10⁻⁹ m',count:7,next:'atom',name:'分子结构',desc:'用简化键连接原子，展示几何关系而非真实化学求解。',rules:['键连接','结构组合','振动近似'],time:'分子时间 · 示意',color:'#70c8ff'},
    {id:'atom',cn:'原子',en:'ATOM',unit:'粒子样本',scale:'~10⁻¹⁰ m',count:19,next:'particle',name:'原子与概率云',desc:'电子概率云的程序化视觉；不是电子经典轨道。',rules:['概率分布示意','尺度映射','边界条件'],time:'原子时间 · 示意',color:'#bb9dff'},
    {id:'particle',cn:'微观',en:'PARTICLE',unit:'场采样点',scale:'≤10⁻¹⁵ m',count:80,next:null,name:'微观场',desc:'抽象波场采样，用于演示底层模块；不求解量子场。',rules:['波动示意','局部采样','场表示'],time:'微观时间 · 示意',color:'#eb91bd'}
  ];
  const DETAILS = {low:0.32,medium:0.65,high:1};
  // Per-domain sampling cadence, in abstract ticks, not physical time units.
  const CADENCE={universe:20,galaxy:5,system:1,planet:4,ecosystem:3,organism:2,cell:1,molecule:1,atom:1,particle:1};
  function hash(input) { let h=2166136261; const s=String(input); for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619);} return h>>>0; }
  function rng(seed) { let a=seed>>>0; return function(){ a=(a+0x6D2B79F5)|0; let t=Math.imul(a^(a>>>15),1|a); t^=t+Math.imul(t^(t>>>7),61|t); return ((t^(t>>>14))>>>0)/4294967296; }; }
  function clamp(x,a,b){return Math.max(a,Math.min(b,x));}
  function round(x,n=3){return Number(x.toFixed(n));}
  function nodeAt(path){return LEVELS[path.length-1]||LEVELS[0];}
  function makeNode(level, i, seed, parent) {
    const r=rng(hash(`${seed}/${parent}/${level.id}/${i}`));
    const a=r()*TAU, u=r(), v=r(), w=r(), z=r(), mass=0.2+u*9.8;
    const tag=level.next?LEVELS.find(x=>x.id===level.next).cn:'采样';
    return {id:`${level.next||'sample'}-${String(i+1).padStart(3,'0')}`,name:`${tag} ${String(i+1).padStart(3,'0')}`,index:i,a,u,v,w,z,mass,color:level.color,radius:0.07+u*0.75,kind:level.next||'sample'};
  }
  class LRU {
    constructor(capacity=8){this.capacity=capacity;this.map=new Map();this.hits=0;this.misses=0;this.evictions=0;}
    get(key,factory){if(this.map.has(key)){const v=this.map.get(key);this.map.delete(key);this.map.set(key,v);this.hits++;return v;}this.misses++;const v=factory();this.map.set(key,v);if(this.map.size>this.capacity){this.map.delete(this.map.keys().next().value);this.evictions++;}return v;}
    clear(){this.map.clear();this.hits=0;this.misses=0;this.evictions=0;}
  }
  const EVENTS={pulse:'能量脉冲',gravity:'轨道倍率',spawn:'注入对象',avatar:'外部访客'};
  function modelState(node,scene,tick){const phase=scene.effect.phase;const energy=clamp(.2+node.u*.65+.09*Math.sin(phase*.01+node.a)+scene.effect.pulse*.035,0,2);return {energy:round(energy),activity:round(.5+.5*Math.sin(phase*.017+node.a)),phase:round((node.a+phase*.01)%TAU),tick:scene.sampleTick};}
  function normalizeEvent(raw, order){
    if(!raw||!EVENTS[raw.type])throw new Error('未知外部指令');
    const t=Number(raw.tick);if(!Number.isFinite(t)||t<0||t>MAX_TICK)throw new Error('事件时间超出范围');
    let value=Number(raw.value);if(!Number.isFinite(value))throw new Error('事件参数无效');
    value=raw.type==='gravity'?clamp(value,0.25,3):clamp(value,0,5);
    const path=Array.isArray(raw.path)?raw.path.map(s=>String(s).slice(0,60)).slice(0,10):['root'];
    if(!path.length||path[0]!=='root')throw new Error('路径无效');
    return {tick:Math.floor(t),type:raw.type,value:round(value),path,id:String(raw.id||`event-${order}`).slice(0,100),order};
  }
  class Universe {
    constructor(seed=313){this.seed=seed>>>0;this.tick=0;this.path=['root'];this.detail='high';this.cache=new LRU(8);this.events=[];this.checkpoints=new LRU(24);this.external=false;}
    reset(seed=this.seed){this.seed=Number(seed)>>>0;this.tick=0;this.path=['root'];this.events=[];this.cache.clear();this.checkpoints.clear();}
    rewind(){this.tick=0;}
    setTime(t){this.tick=clamp(Math.floor(Number(t)||0),0,MAX_TICK);}
    setDetail(d){if(DETAILS[d])this.detail=d;}
    navigate(depth){this.path=this.path.slice(0,clamp(depth+1,1,LEVELS.length));}
    enter(id){if(this.path.length<LEVELS.length&&this.scene().nodes.some(n=>n.id===id)&&!String(id).startsWith('ext-')){this.path=this.path.concat(id);return true;}return false;}
    goLevel(index){index=clamp(index,0,LEVELS.length-1);while(this.path.length-1>index)this.path.pop();while(this.path.length-1<index){const s=this.scene();this.path=this.path.concat(s.nodes[0].id);} }
    addEvent(raw){if(this.events.length>=1000)throw new Error('事件日志最多1000条');const e=normalizeEvent(raw,1+this.events.reduce((max,x)=>Math.max(max,x.order),0));if(this.events.some(x=>x.id===e.id))return false;this.events.push(e);this.events.sort((a,b)=>a.tick-b.tick||a.order-b.order);this.checkpoints.clear();return true;}
    effect(path=this.path,t=this.tick){const key=path.join('/');let rate=1,phase=t,last=0,pulse=0;const objects=[];for(const e of this.events){if(e.tick>t)break;if(e.path.join('/')!==key)continue;if(e.type==='gravity'){phase+=(rate-1)*(e.tick-last);rate=e.value;last=e.tick;}if(e.type==='pulse')pulse+=e.value*Math.exp(-(t-e.tick)/90);if(e.type==='spawn'||e.type==='avatar')objects.push(e);}phase+=(rate-1)*(t-last);return {rate,phase,pulse,objects};}
    scene(){const level=nodeAt(this.path),path=this.path.join('/');const count=['system','molecule','atom'].includes(level.id)?level.count:Math.max(8,Math.ceil(level.count*DETAILS[this.detail]));const key=`${this.seed}:${path}:${count}`;const base=this.cache.get(key,()=>({level,path,key,nodes:Array.from({length:count},(_,i)=>makeNode(level,i,this.seed,path))}));const effect=this.effect();const cadence=CADENCE[level.id];const sampleTick=Math.floor(this.tick/cadence)*cadence;effect.samplePhase=sampleTick===this.tick?effect.phase:this.effect(this.path,sampleTick).phase;const extras=effect.objects.map((e,i)=>{const n=makeNode(level,10000+hash(e.id)%100000000,this.seed,path);return {...n,id:`ext-${e.id}`,name:e.type==='avatar'?'外部访客':'注入对象',external:true,color:'#ffcb82',kind:e.type,mass:Math.max(.1,e.value),strength:e.value};});return {...base,nodes:base.nodes.concat(extras),effect,cadence,sampleTick};}
    snapshot(){return {version:1,seed:this.seed,tick:this.tick,path:this.path.slice(),detail:this.detail,events:this.events.map(e=>({...e,path:e.path.slice()}))};}
    digest(){const canonical=JSON.stringify([this.seed,this.tick,this.events.filter(e=>e.tick<=this.tick).map(e=>[e.tick,e.type,e.value,e.path,e.id,e.order])]);return hash(canonical).toString(16).padStart(8,'0').toUpperCase();}
    checkpoint(){const p=this.snapshot();return this.checkpoints.get(`${this.seed}:${this.tick}:${this.events.length}:${this.path.join('/')}:${this.detail}`,()=>({...p,digest:this.digest()}));}
    restore(data){if(!data||data.version!==1||!Number.isFinite(data.seed)||!Array.isArray(data.events)||data.events.length>1000)throw new Error('无效快照');const path=Array.isArray(data.path)?data.path:['root'];if(path[0]!=='root'||path.length>LEVELS.length||path.some(x=>typeof x!=='string'))throw new Error('无效快照路径');const events=data.events.map((e,i)=>normalizeEvent(e,Number.isInteger(e.order)&&e.order>0&&e.order<=1000000?e.order:i+1));if(new Set(events.map(e=>e.id)).size!==events.length||new Set(events.map(e=>e.order)).size!==events.length)throw new Error('重复事件ID');this.reset(data.seed);this.events=events.sort((a,b)=>a.tick-b.tick||a.order-b.order);this.path=path.slice();this.setTime(data.tick);this.setDetail(data.detail);}
    metrics(){return {regions:this.cache.map.size,hits:this.cache.hits,misses:this.cache.misses,evictions:this.cache.evictions,checkpoints:this.checkpoints.map.size};}
  }
  global.UniCore={Universe, LEVELS, DETAILS, EVENTS, MAX_TICK, TAU, hash,rng,clamp,round,modelState,CADENCE};
})(window);
