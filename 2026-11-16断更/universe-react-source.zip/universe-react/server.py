"""Optional loopback HTTP event gateway. Standard library only, not a public production server."""
import argparse, json, math, uuid
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from threading import Lock
ROOT = Path(__file__).resolve().parent
EVENTS = []
LOCK = Lock()
TYPES = {'pulse', 'gravity', 'spawn', 'avatar'}
class Handler(BaseHTTPRequestHandler):
    def reply(self, code, value):
        data=json.dumps(value,ensure_ascii=False).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        if self.path.split('?')[0] == '/api/events':
            with LOCK: data=list(EVENTS)
            return self.reply(200, {'events':data})
        if self.path in ('/', '/index.html'):
            data=(ROOT/'index.html').read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        return self.reply(404, {'error':'not found'})
    def do_POST(self):
        if self.path!='/api/events': return self.reply(404,{'error':'not found'})
        if self.headers.get('Origin') not in (None, 'http://'+self.headers.get('Host','')): return self.reply(403,{'error':'foreign origin'})
        if self.headers.get_content_type()!='application/json': return self.reply(415,{'error':'JSON required'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=16384: raise ValueError('size')
            e=json.loads(self.rfile.read(length)); t=e['type']; v=float(e['value']); tick=int(e['tick']); p=e.get('path',['root'])
            if t not in TYPES or not math.isfinite(v) or not 0<=tick<=12000 or not isinstance(p,list) or not 1<=len(p)<=10 or p[0]!='root' or not all(isinstance(x,str) and 0<len(x)<=60 for x in p): raise ValueError('invalid event')
            if not ((.25<=v<=3) if t=='gravity' else (0<=v<=5)):raise ValueError('value outside range')
            event={'id':'api-'+uuid.uuid4().hex,'type':t,'value':v,'tick':tick,'path':p}
        except (ValueError,TypeError,KeyError,OverflowError): return self.reply(400,{'error':'invalid event'})
        with LOCK:
            if len(EVENTS)>=1000: return self.reply(409,{'error':'event limit reached'})
            EVENTS.append(event)
        return self.reply(201,event)
    def do_DELETE(self):
        if self.path!='/api/events':return self.reply(404,{'error':'not found'})
        if self.headers.get('Origin') not in (None,'http://'+self.headers.get('Host','')):return self.reply(403,{'error':'foreign origin'})
        with LOCK: EVENTS.clear()
        return self.reply(200,{'ok':True})
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);args=p.parse_args()
    print(f'Universe Lab: http://127.0.0.1:{args.port} (Ctrl+C to stop)',flush=True)
    ThreadingHTTPServer(('127.0.0.1',args.port),Handler).serve_forever()
